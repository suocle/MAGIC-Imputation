#include <RcppEigen.h>

// [[Rcpp::depends(RcppEigen)]]

using namespace Rcpp;
using namespace std;
using Eigen::MatrixXd;


//' A RcppEigen implementation for matrix imputation
//'
//' @param D              An (m x n) matrix to be imputed
//' @param M              An (m x m) Markov Affinity Matrix
//' @param t              The diffusion parameter for imputation
//' @return An (m x n) imputed matrix
//' 
// [[Rcpp::export]]
Eigen::MatrixXd impute(Eigen::MatrixXd& D, Eigen::MatrixXd& M, int t){
  return(M.pow(t)*D);
}
