#' Performs MAGIC Imputation
#'
#' @param D        A (m x n) matrix to be imputed, m is the number of cells, n is the number of genes
#' @param M        A (m x m) Markov Affinity matrix for imputation
#' @param t        Integer, diffusion parameter for imputation, value of 6 to 12 advised
#' @return \code{D}           : An imputed (m x n) matrix using MAGIC algorithm
#' @export

MAGIC <- function(D, M, t){
  D <- as.matrix(D)
  col_names <- colnames(D)
  row_names <- rownames(D)
  M <- as.matrix(M)
  D <- impute(D,M,t)
  return(D)
}